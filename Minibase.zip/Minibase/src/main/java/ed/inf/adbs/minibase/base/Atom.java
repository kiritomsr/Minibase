package ed.inf.adbs.minibase.base;

public class Atom {

}
