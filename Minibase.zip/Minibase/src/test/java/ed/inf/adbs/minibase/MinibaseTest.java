package ed.inf.adbs.minibase;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Unit test for Minibase.
 */

public class MinibaseTest {

    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue() {
        assertTrue(true);
    }
}

