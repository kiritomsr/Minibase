package ed.inf.adbs.minibase.base;

import junit.framework.TestCase;

public class TupleTest extends TestCase {

}